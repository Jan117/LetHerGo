package com.sxxhxscjglxt.common.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.sxxhxscjglxt.common.util.Pagination;

public interface BaseService {
	
	public <T> void saveOrUpdate(T entity);
	
	public <T> T get(Class<T> entityClass,String id);
	
	<T> Pagination<T> getPageData(DetachedCriteria condition, int page, int rows);
	
	public <T> List<T> getQueryData(DetachedCriteria condition);
	
	public <T> void save(T entity);
	
	public <T> void saveBatch(List<T> entitys);
	
	public <T> void update(T entity);
	public <T> void delete(T entity);
}
