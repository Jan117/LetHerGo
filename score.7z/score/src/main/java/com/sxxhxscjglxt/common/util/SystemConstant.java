package com.sxxhxscjglxt.common.util;


public class SystemConstant {

	public static final String KEY_CAPTCHA = "SE_KEY_MM_CODE";
}
