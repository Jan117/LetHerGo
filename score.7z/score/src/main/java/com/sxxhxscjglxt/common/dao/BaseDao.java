package com.sxxhxscjglxt.common.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

public interface BaseDao {

	public <T> void saveOrUpdate(T entity);
	
	public <T> T get(Class<T> entityClass, String id);
	
	public int getRowCountByDetachedCriteria(DetachedCriteria condition);

	public <T> List<T> findByDetachedCriteria(DetachedCriteria condition, int page, int rows);
	
	public <T> List<T> findByDetachedCriteriaNoPage(DetachedCriteria condition);
	public <T> void save(T entity);
	
	public <T> void update(T entity);
	
	public <T> void delete(T entity);

}
