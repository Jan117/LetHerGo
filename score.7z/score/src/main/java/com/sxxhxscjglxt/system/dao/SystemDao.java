package com.sxxhxscjglxt.system.dao;

import java.util.List;

import com.sxxhxscjglxt.common.dao.BaseDao;
import com.sxxhxscjglxt.system.entity.base.ResourceEntity;
import com.sxxhxscjglxt.system.entity.base.UserEntity;

public interface SystemDao extends BaseDao {
	
	public UserEntity getUserByNameAndPassword(UserEntity user);
	
	public List<ResourceEntity> getTreeMenuResource(UserEntity user);
	
	public <T> T findUniqueByProperty(Class<T> entityClass,
			String propertyName, Object value);
}
