package com.sxxhxscjglxt.system.vo;

import java.util.List;

import com.sxxhxscjglxt.system.entity.base.ResourceEntity;
import com.sxxhxscjglxt.system.entity.base.UserEntity;

public class Client implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private UserEntity user;
	private java.lang.String ip;
	private java.util.Date logindatetime;
	private List<ResourceEntity> menuList;
	public UserEntity getUser() {
		return user;
	}
	public void setUser(UserEntity user) {
		this.user = user;
	}

	public java.lang.String getIp() {
		return ip;
	}

	public void setIp(java.lang.String ip) {
		this.ip = ip;
	}

	public java.util.Date getLogindatetime() {
		return logindatetime;
	}

	public void setLogindatetime(java.util.Date logindatetime) {
		this.logindatetime = logindatetime;
	}

	public List<ResourceEntity> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<ResourceEntity> menuList) {
		this.menuList = menuList;
	}


}
