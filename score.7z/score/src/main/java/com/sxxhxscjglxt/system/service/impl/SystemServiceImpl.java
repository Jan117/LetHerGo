package com.sxxhxscjglxt.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sxxhxscjglxt.common.service.impl.BaseServiceImpl;
import com.sxxhxscjglxt.system.dao.SystemDao;
import com.sxxhxscjglxt.system.entity.base.ResourceEntity;
import com.sxxhxscjglxt.system.entity.base.UserEntity;
import com.sxxhxscjglxt.system.service.SystemService;

@Service("systemService")
public class SystemServiceImpl extends BaseServiceImpl implements SystemService {
	
	@Autowired
	private SystemDao systemDao;
	
	@Override
	public UserEntity getUserByNameAndPassword(UserEntity user) {
		
		return systemDao.getUserByNameAndPassword(user);
	}

	@Override
	public List<ResourceEntity> getTreeMenuResource(UserEntity user) {
		return systemDao.getTreeMenuResource(user);
	}

	@Override
	public String getTreeJson(List<ResourceEntity> list) {
		
		return createTreeJson(list);
	}
	
	private String createTreeJson(List<ResourceEntity> list) {
	    JSONArray rootArray = new JSONArray();
	    for (int i=0; i<list.size(); i++) {
	    	ResourceEntity resource = list.get(i);
	      if (resource.getParentResource() == null) {
	        JSONObject rootObj = createBranch(list, resource);
	        rootArray.add(rootObj);
	      }
	    }
	    
	    return rootArray.toString();
	  }
	  private JSONObject createBranch(List<ResourceEntity> list, ResourceEntity currentNode) {
	    JSONObject currentObj = JSONObject.parseObject(JSON.toJSONString(currentNode));
	    JSONArray childArray = new JSONArray();
	    for (int i=0; i<list.size(); i++) {
	    	ResourceEntity newNode = list.get(i);
	      if (newNode.getParentResource()!=null && currentNode.getId().equals(newNode.getParentResource().getId())) {
	        JSONObject childObj = createBranch(list, newNode);
	        childArray.add(childObj);
	      }
	    }
	    
	    if (!childArray.isEmpty()) {
	      currentObj.put("children", childArray);
	    }
	    
	    return currentObj;
	  }
	  
	  public <T> T findUniqueByProperty(Class<T> entityClass,
				String propertyName, Object value) {
			return systemDao.findUniqueByProperty(entityClass, propertyName, value);
		}

}
