package com.sxxhxscjglxt.system.manager;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.sxxhxscjglxt.system.vo.Client;
public class ClientManager {
	
	private static ClientManager instance = new ClientManager();
	
	private ClientManager(){
		
	}
	
	public static ClientManager getInstance(){
		return instance;
	}
	
	private Map<String,Client> map = new HashMap<String, Client>();
	
	public void addClinet(String sessionId,Client client){
		map.put(sessionId, client);
	}
	public void removeClinet(String sessionId){
		map.remove(sessionId);
	}
	public Client getClient(String sessionId){
		return map.get(sessionId);
	}
	public Collection<Client> getAllClient(){
		return map.values();
	}

}
