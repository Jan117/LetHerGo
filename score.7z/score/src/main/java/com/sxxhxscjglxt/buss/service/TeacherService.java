package com.sxxhxscjglxt.buss.service;

import org.hibernate.criterion.DetachedCriteria;

import com.sxxhxscjglxt.buss.entity.base.TeacherEntity;
import com.sxxhxscjglxt.common.util.Pagination;
import com.sxxhxscjglxt.system.service.SystemService;

public interface TeacherService extends SystemService {
	
	
	public Pagination<TeacherEntity> findPageData(DetachedCriteria condition,
			TeacherEntity ve, int page, int rows);
}
