package com.sxxhxscjglxt.buss.service;

import org.hibernate.criterion.DetachedCriteria;

import com.sxxhxscjglxt.buss.entity.base.StudentEntity;
import com.sxxhxscjglxt.common.util.Pagination;
import com.sxxhxscjglxt.system.service.SystemService;

public interface StudentService extends SystemService {
	
	
	public Pagination<StudentEntity> findPageData(DetachedCriteria condition,
			StudentEntity ce, int page, int rows);
}
