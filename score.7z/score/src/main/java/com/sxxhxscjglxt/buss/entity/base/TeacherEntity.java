package com.sxxhxscjglxt.buss.entity.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.sxxhxscjglxt.common.entity.base.BaseEntity;

@Entity
@Table(name="T_B_TEACHER")
public class TeacherEntity extends BaseEntity{
	private static final long serialVersionUID = 3752159363835368243L;
	@Column(length = 20)
	private String teachernum;
	@Column(length = 10)
	private String teachername;
	@Column(length = 20)
	private String phone;
	@Column(length = 10)
	private String tittle;
	@Column(length = 20)
	private Date starttime;
	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public String getTittle() {
		return tittle;
	}

	public void setTittle(String tittle) {
		this.tittle = tittle;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTeachernum() {
		return teachernum;
	}

	public void setTeachernum(String teachernum) {
		this.teachernum = teachernum;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}