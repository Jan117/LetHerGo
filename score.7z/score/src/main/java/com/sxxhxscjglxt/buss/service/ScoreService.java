package com.sxxhxscjglxt.buss.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.sxxhxscjglxt.buss.entity.base.ScoreEntity;
import com.sxxhxscjglxt.common.util.Pagination;
import com.sxxhxscjglxt.system.service.SystemService;

public interface ScoreService extends SystemService {
	
	
	public Pagination<ScoreEntity> findPageData(DetachedCriteria condition,
			ScoreEntity ve, int page, int rows,String name,String teachername,String course,String term);
	
	public List<ScoreEntity> findData(DetachedCriteria condition,
			String name,String teachername,String coursename,String term) throws Exception;
}
