$(document).ready(function() {

	$(document).bind("contextmenu", function() {
		return false;
	});

	$(document).bind("selectstart", function() {
		return false;
	});
	
	$(document).keydown(function(event) {

		if ((event.ctrlKey && event.which == 67) || (event.ctrlKey && event.which == 86)) {
			return false;
		}
		if ((event.ctrlKey) && (event.keyCode == 82)) {
			return false;
		}
		if (event.keyCode == 116) {
			return false; 
		}
		if (event.keyCode == 8) {
			return false;
		}
		if ((event.altKey) && ((event.keyCode == 37) || 
		(event.keyCode == 39))) 
		{
			event.returnValue = false;
			return false;
		}

	});
	
});